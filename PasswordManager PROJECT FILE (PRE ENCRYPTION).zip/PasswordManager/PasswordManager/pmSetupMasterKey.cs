﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PasswordManager
{
    public partial class pmSetupMasterKey : Form
    {
        public static pmSetupMasterKey instance;

        public string createNewMasterKey_Path = "PMMASTER.pmd";
        public pmSetupMasterKey()
        {
            InitializeComponent();
        }

        private void pmSetupMasterKey_Load(object sender, EventArgs e)
        {

        }

        private void createKeyButton_Click(object sender, EventArgs e)
        {
            if (masterKeyInput.Text != "")
            {
                MessageBox.Show("Master Key Successfully Created!");

                try 
                {
                    string content = masterKeyInput.Text;
                    File.WriteAllText(createNewMasterKey_Path, content);
                }
                catch(Exception ex) 
                {
                    MessageBox.Show($"ERROR: {ex.Message}");
                }
            }
            else 
            {
                MessageBox.Show("Please Enter A Password!");
            }
        }
    }
}
