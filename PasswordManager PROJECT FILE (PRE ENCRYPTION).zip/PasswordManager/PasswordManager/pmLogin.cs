﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace PasswordManager
{
    public partial class pmLogin : Form
    {
        public static pmLogin instance;

        public string masterFile_Path = "PMMASTER.pmd";

        public pmLogin()
        {
            InitializeComponent();
        }

        private void pmLogin_Load(object sender, EventArgs e)
        {

        }

        private void loginButton_Click(object sender, EventArgs e)
        {
            if (File.Exists(masterFile_Path))
            {
                if (masterKeyInput.Text != File.ReadAllText(masterFile_Path))
                {
                    MessageBox.Show("ERROR | MASTER KEY INCORRECT");
                }
                else
                {
                    MessageBox.Show("SUCCESS | WELCOME BACK");

                    pmMain managerMain = new pmMain();

                    managerMain.Show();


                }
            }
            else
            {
                MessageBox.Show("No Master Data Found | Create A New Key");
            }
        }

        private void createMasterButton_Click(object sender, EventArgs e)
        {
            if (File.Exists(masterFile_Path))
            {
                MessageBox.Show("Master Key Already Exists | You Can Only Have One Key");
            }
            else
            {
                pmSetupMasterKey setupKeyForm = new pmSetupMasterKey();

                setupKeyForm.Show();
            }


        }

        private void masterKeyInput_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
