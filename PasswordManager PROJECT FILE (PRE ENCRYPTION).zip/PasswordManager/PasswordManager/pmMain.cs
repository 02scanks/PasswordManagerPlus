﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PasswordManager
{
    public partial class pmMain : Form
    {
        public string password_DataFile = "PMDATA.pmd";
        public string content;

        public pmMain()
        {
            InitializeComponent();

            if (File.Exists(password_DataFile))
            {
                content = File.ReadAllText(password_DataFile);

                passwordDisplayBox.Text = content;
            }
        }

        private void passwordDisplayBox_TextChanged(object sender, EventArgs e)
        {

        }

        private void addNewPassword_Click(object sender, EventArgs e)
        {
            pmAddPassword addPasswordForm = new pmAddPassword();

            addPasswordForm.Show();
        }

        private void refreshButton_Click(object sender, EventArgs e)
        {
            if (File.Exists(password_DataFile))
            {
                content = File.ReadAllText(password_DataFile);

                passwordDisplayBox.Text = content;
            }
            else 
            {
                passwordDisplayBox.Text = null;
            }
        }

        private void clearButton_Click(object sender, EventArgs e)
        {
            if (File.Exists(password_DataFile))
            {
                File.Delete(password_DataFile);
            }
        }
    }
}
