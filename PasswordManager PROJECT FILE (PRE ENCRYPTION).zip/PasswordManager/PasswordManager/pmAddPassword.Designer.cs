﻿namespace PasswordManager
{
    partial class pmAddPassword
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(pmAddPassword));
            passwordText = new TextBox();
            userNameText = new TextBox();
            websiteNameText = new TextBox();
            websiteLabel = new Label();
            userNameLabel = new Label();
            passWordLabel = new Label();
            addButton = new Button();
            panel1 = new Panel();
            pictureBox1 = new PictureBox();
            fillerLabel = new Label();
            label1 = new Label();
            panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // passwordText
            // 
            passwordText.Location = new Point(363, 57);
            passwordText.Name = "passwordText";
            passwordText.PasswordChar = '*';
            passwordText.Size = new Size(100, 23);
            passwordText.TabIndex = 0;
            // 
            // userNameText
            // 
            userNameText.Location = new Point(243, 57);
            userNameText.Name = "userNameText";
            userNameText.Size = new Size(100, 23);
            userNameText.TabIndex = 1;
            // 
            // websiteNameText
            // 
            websiteNameText.Location = new Point(124, 57);
            websiteNameText.Name = "websiteNameText";
            websiteNameText.Size = new Size(100, 23);
            websiteNameText.TabIndex = 2;
            // 
            // websiteLabel
            // 
            websiteLabel.AutoSize = true;
            websiteLabel.Font = new Font("Uni Sans Thin CAPS", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
            websiteLabel.Location = new Point(124, 21);
            websiteLabel.Name = "websiteLabel";
            websiteLabel.Size = new Size(94, 14);
            websiteLabel.TabIndex = 3;
            websiteLabel.Text = "Website Name:";
            // 
            // userNameLabel
            // 
            userNameLabel.AutoSize = true;
            userNameLabel.Font = new Font("Uni Sans Thin CAPS", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
            userNameLabel.Location = new Point(243, 21);
            userNameLabel.Name = "userNameLabel";
            userNameLabel.Size = new Size(71, 14);
            userNameLabel.TabIndex = 4;
            userNameLabel.Text = "Username:";
            // 
            // passWordLabel
            // 
            passWordLabel.AutoSize = true;
            passWordLabel.Font = new Font("Uni Sans Thin CAPS", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
            passWordLabel.Location = new Point(363, 21);
            passWordLabel.Name = "passWordLabel";
            passWordLabel.Size = new Size(71, 14);
            passWordLabel.TabIndex = 5;
            passWordLabel.Text = "Password:";
            // 
            // addButton
            // 
            addButton.Font = new Font("Uni Sans Heavy CAPS", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            addButton.Location = new Point(22, 80);
            addButton.Name = "addButton";
            addButton.Size = new Size(75, 23);
            addButton.TabIndex = 6;
            addButton.Text = "Add";
            addButton.UseVisualStyleBackColor = true;
            addButton.Click += addButton_Click;
            // 
            // panel1
            // 
            panel1.BackColor = Color.FromArgb(224, 251, 252);
            panel1.Controls.Add(pictureBox1);
            panel1.Controls.Add(addButton);
            panel1.Dock = DockStyle.Left;
            panel1.Location = new Point(0, 0);
            panel1.Name = "panel1";
            panel1.Size = new Size(117, 115);
            panel1.TabIndex = 7;
            // 
            // pictureBox1
            // 
            pictureBox1.Dock = DockStyle.Top;
            pictureBox1.Image = (Image)resources.GetObject("pictureBox1.Image");
            pictureBox1.Location = new Point(0, 0);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(117, 80);
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox1.TabIndex = 0;
            pictureBox1.TabStop = false;
            // 
            // fillerLabel
            // 
            fillerLabel.AutoSize = true;
            fillerLabel.Location = new Point(230, 60);
            fillerLabel.Name = "fillerLabel";
            fillerLabel.Size = new Size(10, 15);
            fillerLabel.TabIndex = 8;
            fillerLabel.Text = "|";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(347, 60);
            label1.Name = "label1";
            label1.Size = new Size(10, 15);
            label1.TabIndex = 9;
            label1.Text = "|";
            // 
            // pmAddPassword
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(152, 193, 217);
            ClientSize = new Size(496, 115);
            Controls.Add(label1);
            Controls.Add(fillerLabel);
            Controls.Add(panel1);
            Controls.Add(passWordLabel);
            Controls.Add(userNameLabel);
            Controls.Add(websiteLabel);
            Controls.Add(websiteNameText);
            Controls.Add(userNameText);
            Controls.Add(passwordText);
            Icon = (Icon)resources.GetObject("$this.Icon");
            Name = "pmAddPassword";
            Text = "Password Manager | Add Password";
            Load += pmAddPassword_Load;
            panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox passwordText;
        private TextBox userNameText;
        private TextBox websiteNameText;
        private Label websiteLabel;
        private Label userNameLabel;
        private Label passWordLabel;
        private Button addButton;
        private Panel panel1;
        private PictureBox pictureBox1;
        private Label fillerLabel;
        private Label label1;
    }
}