﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PasswordManager
{
    public partial class pmAddPassword : Form
    {
        string websiteName;
        string userName;
        string password;

        public string password_DataFile = "PMDATA.pmd";

        public pmAddPassword()
        {
            InitializeComponent();
        }

        private void pmAddPassword_Load(object sender, EventArgs e)
        {

        }

        private void addButton_Click(object sender, EventArgs e)
        {
            websiteName = websiteNameText.Text;
            userName = userNameText.Text;
            password = passwordText.Text;

            if (websiteNameText.Text != "" && userNameText.Text != "" && passwordText.Text != "") 
            {
                try 
                {   
                    String content = Environment.NewLine + $"{websiteName} | {userName}  | {password}";
                    File.AppendAllText(password_DataFile, content);
                    MessageBox.Show("Password Added");
                }
                catch(Exception ex) 
                {
                    MessageBox.Show($"ERROR: {ex.Message}");
                }
            }
            else 
            {
                MessageBox.Show("ERROR: Please Enter All Fields");
            }
        }
    }
}
