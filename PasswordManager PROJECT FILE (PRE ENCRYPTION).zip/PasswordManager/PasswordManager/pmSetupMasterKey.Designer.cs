﻿namespace PasswordManager
{
    partial class pmSetupMasterKey
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(pmSetupMasterKey));
            masterKeyInput = new TextBox();
            titleText = new Label();
            createKeyButton = new Button();
            showKeyCheckBox = new CheckBox();
            panel1 = new Panel();
            pictureBox1 = new PictureBox();
            panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // masterKeyInput
            // 
            masterKeyInput.Location = new Point(120, 42);
            masterKeyInput.Name = "masterKeyInput";
            masterKeyInput.PasswordChar = '*';
            masterKeyInput.Size = new Size(293, 23);
            masterKeyInput.TabIndex = 0;
            // 
            // titleText
            // 
            titleText.AutoSize = true;
            titleText.Font = new Font("Uni Sans Heavy CAPS", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            titleText.Location = new Point(120, 14);
            titleText.Name = "titleText";
            titleText.Size = new Size(238, 23);
            titleText.TabIndex = 1;
            titleText.Text = "Create New Master Key:";
            // 
            // createKeyButton
            // 
            createKeyButton.Font = new Font("Uni Sans Heavy CAPS", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            createKeyButton.Location = new Point(12, 96);
            createKeyButton.Name = "createKeyButton";
            createKeyButton.Size = new Size(75, 23);
            createKeyButton.TabIndex = 2;
            createKeyButton.Text = "Create Key";
            createKeyButton.UseVisualStyleBackColor = true;
            createKeyButton.Click += createKeyButton_Click;
            // 
            // showKeyCheckBox
            // 
            showKeyCheckBox.AutoSize = true;
            showKeyCheckBox.Font = new Font("Uni Sans Thin CAPS", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
            showKeyCheckBox.Location = new Point(120, 71);
            showKeyCheckBox.Name = "showKeyCheckBox";
            showKeyCheckBox.Size = new Size(124, 18);
            showKeyCheckBox.TabIndex = 3;
            showKeyCheckBox.Text = "Show Password";
            showKeyCheckBox.UseVisualStyleBackColor = true;
            // 
            // panel1
            // 
            panel1.BackColor = Color.FromArgb(224, 251, 252);
            panel1.Controls.Add(pictureBox1);
            panel1.Controls.Add(createKeyButton);
            panel1.Dock = DockStyle.Left;
            panel1.Location = new Point(0, 0);
            panel1.Name = "panel1";
            panel1.Size = new Size(102, 126);
            panel1.TabIndex = 4;
            // 
            // pictureBox1
            // 
            pictureBox1.Dock = DockStyle.Top;
            pictureBox1.Image = (Image)resources.GetObject("pictureBox1.Image");
            pictureBox1.Location = new Point(0, 0);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(102, 90);
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox1.TabIndex = 0;
            pictureBox1.TabStop = false;
            // 
            // pmSetupMasterKey
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(152, 193, 217);
            ClientSize = new Size(444, 126);
            Controls.Add(panel1);
            Controls.Add(showKeyCheckBox);
            Controls.Add(titleText);
            Controls.Add(masterKeyInput);
            FormBorderStyle = FormBorderStyle.Fixed3D;
            Icon = (Icon)resources.GetObject("$this.Icon");
            Name = "pmSetupMasterKey";
            Text = "Password Manager | Setup Master Key";
            Load += pmSetupMasterKey_Load;
            panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox masterKeyInput;
        private Label titleText;
        private Button createKeyButton;
        private CheckBox showKeyCheckBox;
        private Panel panel1;
        private PictureBox pictureBox1;
    }
}