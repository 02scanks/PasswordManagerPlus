﻿using System.Text;
using System.Security.Cryptography;

namespace PasswordManager
{
    public partial class pmLogin : Form
    {
        private static pmLogin instance;

        private static readonly string keyFile = "key.bin";
        private static readonly string ivFile = "iv.bin";

        public readonly byte[] Key = GenerateKey();
        public readonly byte[] IV = GenerateIV();

        public string masterFile_Path = "PMMASTER.pmd";

        public pmLogin()
        {
            InitializeComponent();

            // ENSURE THERES ONLY ONE INSTANCE OF THIS FORM ALLOWED TO RUN
            if (instance != null && instance != this)
            {
                MessageBox.Show("Password Manager Instance Already Running!");
                this.Hide();
                return;
            }
            else
            {
                instance = this;
            }


            if (File.Exists(keyFile) && File.Exists(ivFile))
            {
                Key = LoadKey(keyFile);
                IV = LoadIV(ivFile);
            }
            else
            {
                Key = GenerateKey();
                IV = GenerateIV();
                StoreKeyAndIV(Key, IV, keyFile, ivFile);
            }
        }

        private void loginButton_Click(object sender, EventArgs e)
        {
            if (File.Exists(masterFile_Path))
            {
                DecryptOnLogin();
            }
            else
            {
                MessageBox.Show("No Master Data Found | Create A New Key");
            }
        }

        private void createMasterButton_Click(object sender, EventArgs e)
        {
            if (File.Exists(masterFile_Path))
            {
                MessageBox.Show("Master Key Already Exists | You Can Only Have One Key");
            }
            else
            {
                pmSetupMasterKey setupKeyForm = new pmSetupMasterKey();

                setupKeyForm.Show();
            }


        }


        #region DECRYPTION 


        public static void StoreKeyAndIV(byte[] key, byte[] iv, string keyFile, string ivFile)
        {
            File.WriteAllBytes(keyFile, key);
            File.WriteAllBytes(ivFile, iv);
        }

        public static byte[] LoadKey(string keyFile)
        {
            return File.ReadAllBytes(keyFile);
        }

        public static byte[] LoadIV(string ivFile)
        {
            return File.ReadAllBytes(ivFile);
        }


        public static byte[] GenerateKey()
        {
            using (Aes aes = Aes.Create())
            {
                aes.GenerateKey();
                return aes.Key;
            }
        }

        public static byte[] GenerateIV()
        {
            using (Aes aes = Aes.Create())
            {
                aes.GenerateIV();
                return aes.IV;
            }
        }


        public void DecryptOnLogin() 
        {
            pmAddPassword decryptionMain = new pmAddPassword();

            if (File.Exists(masterFile_Path))
            {
                string[] encryptedLines = File.ReadAllLines(masterFile_Path);
                StringBuilder fullDecryption = new StringBuilder();

                foreach (string encryptedLine in encryptedLines)
                {
                    if (!string.IsNullOrWhiteSpace(encryptedLine))
                    {
                        string decryptedLine = decryptionMain.DecryptString(encryptedLine, decryptionMain.Key, decryptionMain.IV);
                        fullDecryption.Append(decryptedLine);
                    }
                }

                string fullDecryptedString = fullDecryption.ToString();

                if(masterKeyInput.Text == fullDecryptedString) 
                {
                    
                }


                if (masterKeyInput.Text != fullDecryptedString)
                {
                    MessageBox.Show("ERROR | MASTER KEY INCORRECT");
                }
                else
                {
                        MessageBox.Show("SUCCESS | WELCOME BACK");

                        pmMain managerMain = new pmMain();

                        managerMain.Show();
                        this.Hide();
                }
            }
        }

        #endregion
    }
}
