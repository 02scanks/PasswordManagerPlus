﻿namespace PasswordManager
{
    partial class pmMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(pmMain));
            addNewPassword = new Button();
            titleText = new Label();
            passwordDisplayBox = new RichTextBox();
            refreshButton = new Button();
            clearButton = new Button();
            infoPanel = new Panel();
            logoBox = new PictureBox();
            infoPanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)logoBox).BeginInit();
            SuspendLayout();
            // 
            // addNewPassword
            // 
            addNewPassword.Font = new Font("Uni Sans Heavy CAPS", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            addNewPassword.Location = new Point(12, 105);
            addNewPassword.Name = "addNewPassword";
            addNewPassword.Size = new Size(75, 23);
            addNewPassword.TabIndex = 0;
            addNewPassword.Text = "Add";
            addNewPassword.UseVisualStyleBackColor = true;
            addNewPassword.Click += addNewPassword_Click;
            // 
            // titleText
            // 
            titleText.AutoSize = true;
            titleText.Font = new Font("Uni Sans Heavy CAPS", 11.9999981F, FontStyle.Bold, GraphicsUnit.Point, 0);
            titleText.Location = new Point(171, 9);
            titleText.Name = "titleText";
            titleText.Size = new Size(179, 19);
            titleText.TabIndex = 1;
            titleText.Text = "Password Manager +";
            // 
            // passwordDisplayBox
            // 
            passwordDisplayBox.BackColor = Color.White;
            passwordDisplayBox.BorderStyle = BorderStyle.None;
            passwordDisplayBox.Font = new Font("Arial", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
            passwordDisplayBox.Location = new Point(107, 42);
            passwordDisplayBox.Name = "passwordDisplayBox";
            passwordDisplayBox.ReadOnly = true;
            passwordDisplayBox.Size = new Size(308, 203);
            passwordDisplayBox.TabIndex = 2;
            passwordDisplayBox.Text = "";
            passwordDisplayBox.TextChanged += passwordDisplayBox_TextChanged;
            // 
            // refreshButton
            // 
            refreshButton.Font = new Font("Uni Sans Heavy CAPS", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            refreshButton.Location = new Point(12, 154);
            refreshButton.Name = "refreshButton";
            refreshButton.Size = new Size(75, 23);
            refreshButton.TabIndex = 3;
            refreshButton.Text = "Refresh";
            refreshButton.UseVisualStyleBackColor = true;
            refreshButton.Click += refreshButton_Click;
            // 
            // clearButton
            // 
            clearButton.Font = new Font("Uni Sans Heavy CAPS", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            clearButton.Location = new Point(12, 206);
            clearButton.Name = "clearButton";
            clearButton.Size = new Size(75, 23);
            clearButton.TabIndex = 4;
            clearButton.Text = "Clear";
            clearButton.UseVisualStyleBackColor = true;
            clearButton.Click += clearButton_Click;
            // 
            // infoPanel
            // 
            infoPanel.BackColor = Color.FromArgb(224, 251, 252);
            infoPanel.Controls.Add(logoBox);
            infoPanel.Controls.Add(refreshButton);
            infoPanel.Controls.Add(clearButton);
            infoPanel.Controls.Add(addNewPassword);
            infoPanel.Dock = DockStyle.Left;
            infoPanel.Location = new Point(0, 0);
            infoPanel.Name = "infoPanel";
            infoPanel.Size = new Size(101, 257);
            infoPanel.TabIndex = 5;
            // 
            // logoBox
            // 
            logoBox.Dock = DockStyle.Top;
            logoBox.Image = (Image)resources.GetObject("logoBox.Image");
            logoBox.Location = new Point(0, 0);
            logoBox.Name = "logoBox";
            logoBox.Size = new Size(101, 89);
            logoBox.SizeMode = PictureBoxSizeMode.StretchImage;
            logoBox.TabIndex = 5;
            logoBox.TabStop = false;
            // 
            // pmMain
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(152, 193, 217);
            ClientSize = new Size(434, 257);
            Controls.Add(infoPanel);
            Controls.Add(passwordDisplayBox);
            Controls.Add(titleText);
            FormBorderStyle = FormBorderStyle.Fixed3D;
            Icon = (Icon)resources.GetObject("$this.Icon");
            MaximizeBox = false;
            Name = "pmMain";
            Text = "Password Manager | Main";
            infoPanel.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)logoBox).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button addNewPassword;
        private Label titleText;
        private RichTextBox passwordDisplayBox;
        private Button refreshButton;
        private Button clearButton;
        private Panel infoPanel;
        private PictureBox logoBox;
    }
}