﻿namespace PasswordManager
{
    public partial class pmMain : Form
    {
        private static pmMain instance;

        public string decryptedLine;
        public string password_DataFile = "PMDATA.pmd";
        public string content;
        List<string> decryptedLines;

        public pmMain()
        {
            InitializeComponent();

            // ENSURE THERES ONLY ONE INSTANCE OF THIS FORM ALLOWED TO RUN
            if (instance != null && instance != this)
            {
                MessageBox.Show("Password Manager Instance Already Running!");
                this.Close();
            }
            else
            {
                instance = this;
            }

            Decrypt();

            this.FormClosing += pmMain_FormClosing;
        }

        private void passwordDisplayBox_TextChanged(object sender, EventArgs e)
        {

        }

        private void addNewPassword_Click(object sender, EventArgs e)
        {
            pmAddPassword addPasswordForm = new pmAddPassword();

            addPasswordForm.Show();
        }

        
        private void refreshButton_Click(object sender, EventArgs e)
        {
            if (File.Exists(password_DataFile))
            {
                passwordDisplayBox.Clear();
                Decrypt();
            }
            else
            {
                passwordDisplayBox.Text = null;
            }
        }

        private void clearButton_Click(object sender, EventArgs e)
        {
            if (File.Exists(password_DataFile))
            {
                File.Delete(password_DataFile);
                passwordDisplayBox.Clear();
            }
        }

        private void pmMain_FormClosing(object sender, FormClosingEventArgs e) 
        {
            Application.ExitThread();
        }

        private void Decrypt() 
        {
            pmAddPassword decryptionMain = new pmAddPassword();

            if (File.Exists(password_DataFile))
            {
                string[] encryptedLines = File.ReadAllLines(password_DataFile);

                foreach(string encryptedLine in encryptedLines) 
                {
                    if(!string.IsNullOrWhiteSpace(encryptedLine)) 
                    {
                        decryptedLine = decryptionMain.DecryptString(encryptedLine, decryptionMain.Key, decryptionMain.IV);
                        passwordDisplayBox.AppendText(decryptedLine + "\n");
                    }
                }
            }
        }

    }
}
