﻿namespace PasswordManager
{
    partial class pmLogin
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(pmLogin));
            loginButton = new Button();
            masterKeyInput = new TextBox();
            masterKeyLabel = new Label();
            createMasterButton = new Button();
            infoPanel = new Panel();
            logoBox = new PictureBox();
            label1 = new Label();
            infoPanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)logoBox).BeginInit();
            SuspendLayout();
            // 
            // loginButton
            // 
            loginButton.Font = new Font("Uni Sans Heavy CAPS", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            loginButton.Location = new Point(12, 120);
            loginButton.Name = "loginButton";
            loginButton.Size = new Size(75, 23);
            loginButton.TabIndex = 0;
            loginButton.Text = "Login";
            loginButton.UseVisualStyleBackColor = true;
            loginButton.Click += loginButton_Click;
            // 
            // masterKeyInput
            // 
            masterKeyInput.Location = new Point(113, 48);
            masterKeyInput.Name = "masterKeyInput";
            masterKeyInput.PasswordChar = '*';
            masterKeyInput.Size = new Size(193, 23);
            masterKeyInput.TabIndex = 1;
            // 
            // masterKeyLabel
            // 
            masterKeyLabel.AutoSize = true;
            masterKeyLabel.Font = new Font("Uni Sans Heavy CAPS", 11.9999981F, FontStyle.Bold, GraphicsUnit.Point, 238);
            masterKeyLabel.Location = new Point(113, 9);
            masterKeyLabel.Name = "masterKeyLabel";
            masterKeyLabel.Size = new Size(103, 19);
            masterKeyLabel.TabIndex = 2;
            masterKeyLabel.Text = "Master Key:";
            // 
            // createMasterButton
            // 
            createMasterButton.Font = new Font("Uni Sans Heavy CAPS", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            createMasterButton.Location = new Point(12, 149);
            createMasterButton.Name = "createMasterButton";
            createMasterButton.Size = new Size(75, 23);
            createMasterButton.TabIndex = 3;
            createMasterButton.Text = "Create Master Key";
            createMasterButton.UseVisualStyleBackColor = true;
            createMasterButton.Click += createMasterButton_Click;
            // 
            // infoPanel
            // 
            infoPanel.BackColor = Color.FromArgb(224, 251, 252);
            infoPanel.Controls.Add(logoBox);
            infoPanel.Controls.Add(loginButton);
            infoPanel.Controls.Add(createMasterButton);
            infoPanel.Dock = DockStyle.Left;
            infoPanel.Location = new Point(0, 0);
            infoPanel.Name = "infoPanel";
            infoPanel.Size = new Size(107, 184);
            infoPanel.TabIndex = 4;
            // 
            // logoBox
            // 
            logoBox.Dock = DockStyle.Top;
            logoBox.Image = (Image)resources.GetObject("logoBox.Image");
            logoBox.Location = new Point(0, 0);
            logoBox.Name = "logoBox";
            logoBox.Size = new Size(107, 114);
            logoBox.SizeMode = PictureBoxSizeMode.StretchImage;
            logoBox.TabIndex = 4;
            logoBox.TabStop = false;
            // 
            // label1
            // 
            label1.Font = new Font("Uni Sans Thin CAPS", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label1.Location = new Point(113, 87);
            label1.Name = "label1";
            label1.Size = new Size(193, 56);
            label1.TabIndex = 5;
            label1.Text = "Please Enter Your Master Key In The Field Above And Click Login When You're Ready!";
            label1.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // pmLogin
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(152, 193, 217);
            ClientSize = new Size(322, 184);
            Controls.Add(label1);
            Controls.Add(infoPanel);
            Controls.Add(masterKeyLabel);
            Controls.Add(masterKeyInput);
            FormBorderStyle = FormBorderStyle.FixedDialog;
            Icon = (Icon)resources.GetObject("$this.Icon");
            MaximizeBox = false;
            Name = "pmLogin";
            Text = "Password Manager | Login";
            infoPanel.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)logoBox).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button loginButton;
        private TextBox masterKeyInput;
        private Label masterKeyLabel;
        private Button createMasterButton;
        private Panel infoPanel;
        private PictureBox logoBox;
        private Label label1;
    }
}