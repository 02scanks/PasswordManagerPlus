﻿using System.Security.Cryptography;

namespace PasswordManager
{
    public partial class pmSetupMasterKey : Form
    {
        public static pmSetupMasterKey instance;

        public string createNewMasterKey_Path = "PMMASTER.pmd";
        public pmSetupMasterKey()
        {
            InitializeComponent();

            // ENSURE THERES ONLY ONE INSTANCE OF THIS FORM ALLOWED TO RUN
            if (instance != null && instance != this)
            {
                MessageBox.Show("Password Manager Instance Already Running!");
                this.Close();
            }
            else
            {
                instance = this;
            }
        }

        private void createKeyButton_Click(object sender, EventArgs e)
        {
            pmAddPassword cipherControl = new pmAddPassword();
            byte[] IV = cipherControl.IV;
            byte[] Key = cipherControl.Key;

            if (masterKeyInput.Text != "")
            {
                try
                {
                    MessageBox.Show("Master Key Successfully Created!");
                    string content = masterKeyInput.Text;
                    string encryptedContent = EncryptString(content, Key, IV);
                    File.WriteAllText(createNewMasterKey_Path, encryptedContent);

                    this.Close();
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"ERROR: {ex.Message}");
                }
            }
            else
            {
                MessageBox.Show("Please Enter A Password!");
            }
        }


        #region File Encryption And Decryption


        public static void StoreKeyAndIV(byte[] key, byte[] iv, string keyFile, string ivFile)
        {
            File.WriteAllBytes(keyFile, key);
            File.WriteAllBytes(ivFile, iv);
        }

        public static byte[] LoadKey(string keyFile)
        {
            return File.ReadAllBytes(keyFile);
        }

        public static byte[] LoadIV(string ivFile)
        {
            return File.ReadAllBytes(ivFile);
        }


        public static byte[] GenerateKey()
        {
            using (Aes aes = Aes.Create())
            {
                aes.GenerateKey();
                return aes.Key;
            }
        }

        public static byte[] GenerateIV()
        {
            using (Aes aes = Aes.Create())
            {
                aes.GenerateIV();
                return aes.IV;
            }
        }

        public static string EncryptString(string plainText, byte[] key, byte[] iv)
        {
            using (Aes aes = Aes.Create())
            {
                aes.Key = key;
                aes.IV = iv;

                ICryptoTransform encryptor = aes.CreateEncryptor(aes.Key, aes.IV);

                using (MemoryStream ms = new MemoryStream())
                {
                    using (CryptoStream cs = new CryptoStream(ms, encryptor, CryptoStreamMode.Write))
                    {
                        using (StreamWriter sw = new StreamWriter(cs))
                        {
                            sw.Write(plainText);
                        }
                    }

                    return Convert.ToBase64String(ms.ToArray());
                }
            }
        }


        public string DecryptString(string cipherText, byte[] key, byte[] iv)
        {
            using (Aes aes = Aes.Create())
            {
                aes.Key = key;
                aes.IV = iv;

                ICryptoTransform decryptor = aes.CreateDecryptor(aes.Key, aes.IV);

                using (MemoryStream ms = new MemoryStream(Convert.FromBase64String(cipherText)))
                {
                    using (CryptoStream cs = new CryptoStream(ms, decryptor, CryptoStreamMode.Read))
                    {
                        using (StreamReader sr = new StreamReader(cs))
                        {
                            return sr.ReadToEnd();
                        }
                    }
                }
            }
        }


        #endregion

        private void showKeyCheckBox_CheckedChanged(object sender, EventArgs e)
        {
            if(showKeyCheckBox.Checked == true) 
            {
                masterKeyInput.PasswordChar = '\0';
            }
            else 
            {
                masterKeyInput.PasswordChar = '*';
            }
        }
    }
}
