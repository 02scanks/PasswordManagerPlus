﻿using System.Security.Cryptography;

namespace PasswordManager
{

    public partial class pmAddPassword : Form
    {
        private static readonly string keyFile = "key.bin";
        private static readonly string ivFile = "iv.bin";

        public readonly byte[] Key = GenerateKey();
        public readonly byte[] IV = GenerateIV();

        string websiteName;
        string userName;
        string password;

        public string password_DataFile = "PMDATA.pmd";

        public pmAddPassword()
        {
            InitializeComponent();

            if (File.Exists(keyFile) && File.Exists(ivFile))
            {
                Key = LoadKey(keyFile);
                IV = LoadIV(ivFile);
            }
            else
            {
                Key = GenerateKey();
                IV = GenerateIV();
                StoreKeyAndIV(Key, IV, keyFile, ivFile);
            }
        }


        #region File Encryption And Decryption


        public static void StoreKeyAndIV(byte[] key, byte[] iv, string keyFile, string ivFile)
        {
            File.WriteAllBytes(keyFile, key);
            File.WriteAllBytes(ivFile, iv);
        }

        public static byte[] LoadKey(string keyFile)
        {
            return File.ReadAllBytes(keyFile);
        }

        public static byte[] LoadIV(string ivFile)
        {
            return File.ReadAllBytes(ivFile);
        }


        public static byte[] GenerateKey()
        {
            using (Aes aes = Aes.Create())
            {
                aes.GenerateKey();
                return aes.Key;
            }
        }

        public static byte[] GenerateIV() 
        {
            using (Aes aes = Aes.Create()) 
            {
                aes.GenerateIV();
                return aes.IV;
            }
        }

        public static string EncryptString(string plainText, byte[] key, byte[] iv) 
        {
            using (Aes aes = Aes.Create()) 
            {
                aes.Key = key;
                aes.IV = iv;

                ICryptoTransform encryptor = aes.CreateEncryptor(aes.Key, aes.IV);

                using (MemoryStream ms = new MemoryStream()) 
                {
                    using (CryptoStream cs = new CryptoStream(ms, encryptor, CryptoStreamMode.Write)) 
                    {
                        using (StreamWriter sw = new StreamWriter(cs)) 
                        {
                            sw.Write(plainText);
                        }
                    }

                    return Convert.ToBase64String(ms.ToArray());
                }
            }
        }


        public string DecryptString(string cipherText, byte[] key, byte[] iv)
        {
            using (Aes aes = Aes.Create())
            {
                aes.Key = key;
                aes.IV = iv;

                ICryptoTransform decryptor = aes.CreateDecryptor(aes.Key, aes.IV);

                using (MemoryStream ms = new MemoryStream(Convert.FromBase64String(cipherText)))
                {
                    using (CryptoStream cs = new CryptoStream(ms, decryptor, CryptoStreamMode.Read))
                    {
                        using (StreamReader sr = new StreamReader(cs))
                        {
                            return sr.ReadToEnd();
                        }
                    }
                }
            }
        }


        #endregion


        private void addButton_Click(object sender, EventArgs e)
        {
            websiteName = websiteNameText.Text;
            userName = userNameText.Text;
            password = passwordText.Text;

            if (websiteNameText.Text != "" && userNameText.Text != "" && passwordText.Text != "") 
            {
                try 
                {   
                    String content = $"{websiteName} | {userName}  | {password}";
                    string encryptedContent = EncryptString(content, Key, IV);


                    File.AppendAllText(password_DataFile, Environment.NewLine + encryptedContent);
                    MessageBox.Show("Password Added");
                    this.Close();
                }
                catch(Exception ex) 
                {
                    MessageBox.Show($"ERROR: {ex.Message}");
                }
            }
            else 
            {
                MessageBox.Show("ERROR: Please Enter All Fields");
            }
        }
    }
}
